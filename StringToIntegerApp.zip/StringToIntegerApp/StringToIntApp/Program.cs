﻿using System;

namespace StringToIntApp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter the text to convert it to Integer");
                string inputValue = Console.ReadLine();
                string[] inputValueSplit = inputValue.Split(' ');                

                int convertedInt;

                if (inputValueSplit.Length > 1)
                {
                    Int32.TryParse(inputValueSplit[1], out int defaultValue);
                    convertedInt = inputValueSplit[1].ToSafeInt(defaultValue);      // ToSafeInt() as mamber of string class with optional default value
                }
                else
                {
                    Converter.textValue = inputValueSplit[0];
                    convertedInt = Converter.ToSafeInt();   
                }

                if (convertedInt == -1)
                    Console.WriteLine("Invalid input. Unable to convert to integer");
                else
                    Console.WriteLine($"Integer value is {convertedInt}");
                
                Console.WriteLine("Press Esc to quit, Enter to Retry");
                if(Console.ReadKey(true).Key == ConsoleKey.Escape)
                    break;
                Console.WriteLine("");
            }
        }
    }
}
