﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StringToIntApp
{
    public static class Converter
    {
        public static string textValue { get; set; }

        // method that converts textValue into numeric value
        // returns -1 if cannot be converted to integer or textValue is not set
        public static int ToSafeInt()
        {
            int retVal;
            if (Int32.TryParse(textValue, out retVal))
                return retVal;
            else
                return -1;
        }


        // method that workes as an extension method of System.String class
        // it take optional  default value parameter
        public static int ToSafeInt(this string value, int defaultValue = 0)
        {
            int retVal;
            if (Int32.TryParse(value, out retVal))
                return retVal;
            else
                return defaultValue;
        }


    }
}
