﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using StringToIntApp;
using System;
using System.Collections.Generic;
using System.Text;

namespace StringToIntApp.Tests
{
    [TestClass()]
    public class ConverterTests
    {
        [TestMethod()]
        public void validNumericInputTest()
        {
            Converter.textValue = "123";
            int retVal = Converter.ToSafeInt();
            Assert.AreEqual(123, retVal);
        }

        [TestMethod()]
        public void invalidumericInputTest()
        {
            Converter.textValue = "someText";
            int retVal = Converter.ToSafeInt();
            Assert.AreEqual(-1, retVal);
        }

        [TestMethod()]
        public void validTestWithDefaultValue()
        {            
            int retVal = "123".ToSafeInt(1);
            Assert.AreEqual(123, retVal);
        }

        public void validTestWithoutDefaultValue()
        {
            int retVal = "123".ToSafeInt();
            Assert.AreEqual(123, retVal);
        }

        [TestMethod()]
        public void invalidTestWithDefaultValue()
        {
            int retVal = "someText".ToSafeInt(10);
            Assert.AreEqual(10, retVal);
        }

        [TestMethod()]
        public void invalidTestWithoutDefaultValue()
        {
            int retVal = "someText".ToSafeInt();
            Assert.AreEqual(0, retVal);
        }


    }
}